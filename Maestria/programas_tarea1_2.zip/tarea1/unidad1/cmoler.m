%% programa que realiza el algoritmo de C Moler

clear all;
clc

a= 4/3; 
b= a-1; 
c=b+b+b;
u=abs(c-1);

disp(' el valor de u es')
u
disp('el valor de epsilon maquina es ')
eps